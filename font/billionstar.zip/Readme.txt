Hello,

Thanks for downloading 
NOTE: This font is FREE 100% FOR PERSONAL USE ONLY! But any donation are very appreciated. 
All forms of use of fonts without buying a license first must comply with our terms of completing purchases for commercial purposes and will be subject to a Corporate License

visit our website for FULL VERSION font: https://www.ribethstudio.com/

Paypal account for donation: https://www.paypal.me/ribethstudio

Please follow our instagram for update : https://www.instagram.com/studioribeth/

Contact us: hello@ribethstudio.com



Thanks,

Ribeth Std